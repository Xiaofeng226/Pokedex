export default function Title({ text }) {
  return <h1>{text}</h1>;
}
